package com.booksajo.dasibom.junggo.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.booksajo.dasibom.junggo.UsedBookVO;
import com.booksajo.dasibom.junggo.mapper.UsedBookMapper;

@Service
public class UsedBookServiceImpl implements UsedBookService {

    @Autowired
    private UsedBookMapper usedBookMapper;
    
    @Override
    public int getUsedBookCount() {
        return usedBookMapper.selectUsedBookCount();
    }
    
    @Override
    public List<UsedBookVO> getUsedBooksByPage(int startRow, int endRow) {
        Map<String, Integer> params = new HashMap<String, Integer>();
        params.put("startRow", startRow);
        params.put("endRow", endRow);
        return usedBookMapper.selectUsedBooksByPage(params);
    }

    @Override
    public List<UsedBookVO> getAllUsedBooks() {
        return usedBookMapper.selectAll(); // ← Mapper를 통해 DB 호출
    }

    @Override
    public UsedBookVO getUsedBook(int postId) {
        return usedBookMapper.selectId(postId);
    }

    @Override
    public int insertUsedBook(UsedBookVO vo) {
        return usedBookMapper.insert(vo);
    }

    @Override
    public int updateUsedBook(UsedBookVO vo) {
        return usedBookMapper.update(vo);
    }

    @Override
    public int deleteUsedBook(int postId) {
        return usedBookMapper.delete(postId);
    }
    
}
