package com.booksajo.dasibom.junggo.service;

import java.util.List;

import com.booksajo.dasibom.junggo.UsedBookVO;

public interface UsedBookService {
	List<UsedBookVO> getUsedBooksByPage(int startRow, int endRow);
	int getUsedBookCount();
    List<UsedBookVO> getAllUsedBooks();
    UsedBookVO getUsedBook(int postId);
    int insertUsedBook(UsedBookVO vo);
    int updateUsedBook(UsedBookVO vo);
    int deleteUsedBook(int postId);
}
