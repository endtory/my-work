package com.booksajo.dasibom.junggo.mapper;

import java.util.List;
import java.util.Map;

import com.booksajo.dasibom.junggo.UsedBookVO;

public interface UsedBookMapper {
    List<UsedBookVO> selectAll();
    UsedBookVO selectId(int postId);
    int insert(UsedBookVO vo);
    int update(UsedBookVO vo);
    int delete(int postId);
	int selectUsedBookCount();
	List<UsedBookVO> selectUsedBooksByPage(Map<String, Integer> params);
}