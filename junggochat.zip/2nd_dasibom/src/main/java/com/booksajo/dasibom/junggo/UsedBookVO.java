package com.booksajo.dasibom.junggo;

import java.util.Date;
import java.util.List;

public class UsedBookVO {

    private int postId;
    private Date postDate;
    private String title;
    private int price;
    private String isbn;
    private String saleStatus;
    private String imagePath;
    private String saleType;
    private String userId;
    private String content;

    // ✅ 추가된 필드
    private List<String> imagePathList;

    // 기본 생성자
    public UsedBookVO() {}

    // 생성자 (필요시 수정)
    public UsedBookVO(int postId, Date postDate, String title, int price, String isbn,
                      String saleStatus, String imagePath, String saleType,
                      String userId, String content) {
        this.postId = postId;
        this.postDate = postDate;
        this.title = title;
        this.price = price;
        this.isbn = isbn;
        this.saleStatus = saleStatus;
        this.imagePath = imagePath;
        this.saleType = saleType;
        this.userId = userId;
        this.content = content;
    }

    // ✅ Getter & Setter for imagePathList
    public List<String> getImagePathList() {
        return imagePathList;
    }

    public void setImagePathList(List<String> imagePathList) {
        this.imagePathList = imagePathList;
    }

    // 기존 Getter/Setter 생략 없이 그대로 유지
    public int getPostId() { return postId; }
    public void setPostId(int postId) { this.postId = postId; }

    public Date getPostDate() { return postDate; }
    public void setPostDate(Date postDate) { this.postDate = postDate; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public int getPrice() { return price; }
    public void setPrice(int price) { this.price = price; }

    public String getIsbn() { return isbn; }
    public void setIsbn(String isbn) { this.isbn = isbn; }

    public String getSaleStatus() { return saleStatus; }
    public void setSaleStatus(String saleStatus) { this.saleStatus = saleStatus; }

    public String getImagePath() { return imagePath; }
    public void setImagePath(String imagePath) { this.imagePath = imagePath; }

    public String getSaleType() { return saleType; }
    public void setSaleType(String saleType) { this.saleType = saleType; }

    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }

    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }
}
