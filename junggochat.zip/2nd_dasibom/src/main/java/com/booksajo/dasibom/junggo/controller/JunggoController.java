package com.booksajo.dasibom.junggo.controller;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import com.booksajo.dasibom.junggo.UsedBookVO;
import com.booksajo.dasibom.junggo.service.UsedBookService;

@Controller
public class JunggoController {

    @Autowired
    private UsedBookService usedBookService;

    @RequestMapping("/junggo_list.do")
    public String showListPage(@RequestParam(defaultValue = "1") int page, Model model) {
        int pageSize = 10;
        int totalCount = usedBookService.getUsedBookCount();
        int totalPages = (int) Math.ceil((double) totalCount / pageSize);

        if (page < 1) page = 1;
        if (page > totalPages) page = totalPages;

        int startRow = (page - 1) * pageSize + 1;
        int endRow = page * pageSize;

        List<UsedBookVO> list = usedBookService.getUsedBooksByPage(startRow, endRow);

        // 여러 이미지 경로 중 첫 번째만 썸네일용으로 쓰고,
        // 전체 경로 리스트를 VO에 임시로 추가하는 방식
        for (UsedBookVO post : list) {
            String fullPath = post.getImagePath();
            if (fullPath != null && !fullPath.trim().isEmpty()) {
                String[] paths = fullPath.split(";");
                post.setImagePath(paths[0].trim()); // 썸네일용 첫 번째 이미지 설정

                // 리스트로도 이미지 경로를 전달하고 싶다면 UsedBookVO에 List<String> imageList 필드 추가 필요
                List<String> imageList = new ArrayList<String>();
                for (String path : paths) {
                    if (!path.trim().isEmpty()) {
                        imageList.add(path.trim());
                    }
                }
                post.setImagePathList(imageList); // VO에 setter 만들어야 함
            }
        }

        model.addAttribute("usedBookList", list);
        model.addAttribute("currentPage", page);
        model.addAttribute("totalPages", totalPages);
        model.addAttribute("hasPrev", page > 1);
        model.addAttribute("hasNext", page < totalPages);
        model.addAttribute("prevPage", page - 1);
        model.addAttribute("nextPage", page + 1);

        return "junggo_list";
    }


    @RequestMapping("/junggo_view.do")
    public String showViewPage(@RequestParam("postId") int postId, Model model) {
        UsedBookVO book = usedBookService.getUsedBook(postId);

        if (book != null && book.getImagePath() != null && !book.getImagePath().trim().isEmpty()) {
            String[] paths = book.getImagePath().split(";");
            List<String> imageList = new ArrayList<String>();
            for (String path : paths) {
                if (!path.trim().isEmpty()) {
                    imageList.add(path.trim());
                }
            }
            book.setImagePathList(imageList);
            
        }

        model.addAttribute("book", book);
        return "junggo_view";
    }

    @GetMapping("/junggo_write.do")
    public String showWritePage() {
        return "junggo_write";
    }

    @PostMapping("/junggo_write.do")
    public String submitWrite(
        @ModelAttribute UsedBookVO usedBook,
        @RequestParam(value = "images", required = false) MultipartFile[] images,
        HttpServletRequest request
    ) {
        // 작성일 설정
        usedBook.setPostDate(new Date());

        // 이미지 저장 처리
        if (images != null && images.length > 0) {
            String uploadDir = request.getServletContext().getRealPath("/resources/uploads/");
            File uploadPath = new File(uploadDir);
            if (!uploadPath.exists()) uploadPath.mkdirs();

            StringBuilder imagePaths = new StringBuilder();

            for (MultipartFile image : images) {
                if (!image.isEmpty()) {
                    String originalFilename = image.getOriginalFilename();
                    String extension = originalFilename.substring(originalFilename.lastIndexOf("."));
                    String newFileName = UUID.randomUUID().toString() + extension;

                    File dest = new File(uploadPath, newFileName);
                    try {
                        image.transferTo(dest);
                        if (imagePaths.length() > 0) imagePaths.append(";");
                        imagePaths.append("/resources/uploads/").append(newFileName);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
            usedBook.setImagePath(imagePaths.toString());
        }

        usedBookService.insertUsedBook(usedBook);

        return "redirect:/junggo_list.do";
    }

}
