<%@ page language="java" contentType="text/html; charset=UTF-8"
         pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html>
<head>
    <title>다시봄 사이트</title>
</head>
<body>
    <h1>다시봄 사이트에 오신 것을 환영합니다!</h1>
    
    <form action="junggo_list.do" method="get">
        <input type="submit" value="중고 도서 거래/나눔">
    </form>
    
    <form action="junggo_view.do" method="get">
        <input type="submit" value="중고 도서 거래 게시글">
    </form>
    
    <form action="junggo_write.do" method="get">
        <input type="submit" value="글쓰기">
    </form>

</body>
</html>
