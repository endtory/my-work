function toggleDropdown() {
	const dropdown = document.getElementById('mypageDropdown');
	dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
}

// 클릭 바깥을 누르면 닫히도록
window.addEventListener('click', function (e) {
	const dropdown = document.getElementById('mypageDropdown');
	if (!dropdown) return;

	if (!e.target.closest('.header-mypagebtn-container')) {
		dropdown.style.display = 'none';
	}
});