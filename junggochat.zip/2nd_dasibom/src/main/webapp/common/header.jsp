<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>

<!-- CSS -->
<link rel="stylesheet" href="${pageContext.request.contextPath}/css/header.css">

</head>
<body>
	<!-- 헤더 -->
	<div class = "header-logoline">
		<img class = "header-logo-img" src = "${pageContext.request.contextPath}/IMG/Logo.png"></img>
		
		<div class="header-search-container">
			<input class="header-search-Input" type="text" placeholder="검색어를 입력하세요">
			<button class="header-search-btn">🔍</button>
		</div>
		
		<img class = "header-cartbtn-img" src = "${pageContext.request.contextPath}/IMG/cart.jpeg"></img>
		
		<div class="header-mypagebtn-container">
			<img class="header-mypagebtn-img" src="${pageContext.request.contextPath}/IMG/mypage.png" alt="마이페이지" onclick="toggleDropdown()" />
			<div class="header-mypagebtn-dropdown" id="mypageDropdown">
				<button onclick="location.href='login.do'">로그인</button>
				<button onclick="location.href='signup.do'">회원가입</button>
			</div>
		</div>
		
	</div>
	<div class = "header-pathline-container">
		<button class="header-pathbtn">장르별</button>
		<button class="header-pathbtn">중고거래</button>
		<button class="header-pathbtn">베스트</button>
		<button class="header-pathbtn">신상품</button>
		<button class="header-pathbtn">이벤트</button>
		<button class="header-pathbtn">장바구니</button>
		<button class="header-pathbtn">찜</button>
	</div>
	
	<!-- JS -->
	<script src="${pageContext.request.contextPath}/js/script2.js"></script>
</body>
</html>