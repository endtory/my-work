<%@ page language="java" contentType="text/html; charset=UTF-8"
         pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>1:1 채팅</title>

    <!-- CSS -->
    <link rel="stylesheet" href="<%= request.getContextPath() %>/resources/css/chat.css">

    <!-- contextPath 변수 정의 -->
    <script type="text/javascript">
        const contextPath = "<%= request.getContextPath() %>";
    </script>

    <!-- JavaScript -->
	<script src="<%= request.getContextPath() %>/resources/js/chat.js"></script>
</head>
<body>
    <!-- 유저 ID로 제목 표시 -->
    <h2><c:out value="${sellerId}"/>님과의 채팅</h2>

    <!-- 채팅 메시지 영역 -->
    <div id="chatBox" class="chat-container"></div>

    <!-- 메시지 입력 및 전송 -->
    <div class="input-area">
        <input type="text" id="msgInput" placeholder="메시지를 입력하세요" autocomplete="off" onkeydown="if(event.key === 'Enter') { sendMessage(); event.preventDefault(); }" />
        <button onclick="sendMessage()">보내기</button>
    </div>
</body>
</html>
