package com.empmanage.sawon;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.empmanage.sawon.service.BookService;
import com.empmanage.sawon.service.SawonService;
import com.empmanage.sawon.vo.BookSearchResult;
import com.empmanage.sawon.vo.BookVO;
import com.empmanage.sawon.vo.ReviewVO;
import com.empmanage.sawon.vo.SawonVO;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {

	@RequestMapping(value = "/MainPage.do")
	public String MainPage(Model model) throws Exception {
		ArrayList<BookVO> bestlist = bookService.getBest();
		model.addAttribute("bestlist", bestlist);
		return "MainPage";
	}
	
	@Resource(name = "bookService")
	private BookService bookService;
	
	//리뷰 ccid대댓글 수정버전
	@RequestMapping(value = "/bookview.do")
	public String bookView(BookVO bookVO, Model model) {
		
		
	    BookVO telinfo = bookService.getTelinfo(bookVO);
	    if (telinfo == null) {
	        System.out.println("telinfo가 null입니다!!");
	        return "redirect:/MainPage.do"; // 혹은 에러 페이지
	    }

	    // 전체 리뷰 리스트
	    ArrayList<ReviewVO> allReviews = bookService.getAllReviewByIsbn(bookVO.getIsbn());

	    // 리뷰와 댓글 분리 (Java 1.7 이하 호환 방식)
	    List<ReviewVO> reviewList = new ArrayList<ReviewVO>();
	    Map<Integer, List<ReviewVO>> replyMap = new HashMap<Integer, List<ReviewVO>>();
	    double averageRating = bookService.getAverageRating(bookVO.getIsbn());
	    
	    for (ReviewVO r : allReviews) {
	        if (r.getCcid() == null) {
	            reviewList.add(r); // 일반 리뷰
	        } else {
	            if (!replyMap.containsKey(r.getCcid())) {
	                replyMap.put(r.getCcid(), new ArrayList<ReviewVO>());
	            }
	            replyMap.get(r.getCcid()).add(r); // 대댓글 목록에 추가
	        }
	    }

	    model.addAttribute("book", telinfo);
	    model.addAttribute("reviewList", reviewList);   // 리뷰만
	    model.addAttribute("replyMap", replyMap);       // Map<cid, List<댓글들>>
	    model.addAttribute("averageRating", averageRating); // 책 전체 평점
	    
	    return "bookview";
	}	

	@RequestMapping(value = "/books.do", method = RequestMethod.GET)
	public String getBooks(
	    @RequestParam String query,
	    @RequestParam(required = false, defaultValue = "1") Integer startnum,
	    Model model) throws Exception {

	    BookSearchResult result = bookService.searchBooks(query, (startnum - 1) * 10);
	    List<BookVO> books = result.getBooks();
	    int total = result.getTotal();

	    model.addAttribute("books", books);
	    model.addAttribute("query", query);
	    model.addAttribute("total", (int) Math.ceil((double) total / 10));
	    model.addAttribute("pageSize", 10);
	    model.addAttribute("currentPage", startnum);

	    int startPage = ((startnum - 1) / 10) * 10 + 1;
	    model.addAttribute("startPage", startPage);
	    model.addAttribute("endPage", Math.min(startPage + 9, (int) Math.ceil((double) total / 10)));

	    return "bookList";
	}
	
	@RequestMapping(value = "/bestbook.do", method = RequestMethod.GET)
	public String best(Model model) throws Exception {
		ArrayList<BookVO> books = bookService.getBest();
		model.addAttribute("books", books);
		return "BestBook";
		
	}
	
	@RequestMapping(value = "/newbook.do", method = RequestMethod.GET)
	public String newbook(Model model) throws Exception {
		ArrayList<BookVO> books = bookService.getNew();
		model.addAttribute("books", books);
		return "NewBook";
		
	}
	
	
	
	@Resource(name = "sawonService")
	private SawonService sawonService;

	@RequestMapping(value = "/sawonAll.do")
	public String sawonAll(Model model) throws Exception {
		ArrayList<SawonVO> allist = sawonService.getAllSawon();
		model.addAttribute("sawonlist", allist);
		return "sawonAll";
	}

	@RequestMapping(value = "/sawonOne.do")
	public String sawonOne(@ModelAttribute("sawonVO") SawonVO sawonVO, Model model) throws Exception {
		SawonVO alist = sawonService.getSawon(sawonVO);
		model.addAttribute("alist", alist);
		return "sawonOne";
	}

	@RequestMapping(value = "/sawonInsertForm.do")
	public String insertSawonForm(@ModelAttribute("sawonVO") SawonVO sawonVO, Model model) throws Exception {
		return "sawonInsertForm";
	}

	@RequestMapping(value = "/insertSawon.do")
	public String insertSawon(@ModelAttribute("sawonVO") SawonVO sawonVO) throws Exception {
		sawonService.insertSawon(sawonVO);
		return "redirect:sawonAll.do";
	}

	@RequestMapping(value = "/updateSawon.do")
	public String updateSawon(@ModelAttribute("sawonVO") SawonVO sawonVO) throws Exception {
		sawonService.updateSawon(sawonVO);
		return "redirect:sawonAll.do";
	}

	@RequestMapping(value = "/deleteSawon.do")
	public String deleteSawon(@ModelAttribute("sawonVO") SawonVO sawonVO) throws Exception {
		sawonService.deleteSawon(sawonVO);
		return "redirect:sawonAll.do";
	}
	

	// 회원가입 페이지로 이동
	@RequestMapping(value="/signup.do")
	public String goSignup() {
		return "signupForm"; 
	}
	
	// 로그인 페이지로 이동
	@RequestMapping(value="/login.do")
	public String goLogin() {
		return "loginPage"; 
	}


}
