package com.empmanage.sawon.service;

import java.util.ArrayList;
import java.util.List;

import com.empmanage.sawon.vo.UsedBookVO;

public interface UsedBookService {
	UsedBookVO getUsedBook(int post_Id);
	List<UsedBookVO> getAllUsedBooks();
    ArrayList<UsedBookVO> getUsedBooksByPage(int startRow, int endRow); // 페이징
    int getUsedBookCount(); // 총 게시물 수
    int insertUsedBook(UsedBookVO vo);  // 등록
    int updateUsedBook(UsedBookVO vo);  // 수정
    int deleteUsedBook(int post_Id);     // 삭제
}
