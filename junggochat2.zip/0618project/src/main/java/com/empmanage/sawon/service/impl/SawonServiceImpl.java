package com.empmanage.sawon.service.impl;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.ModelAttribute;

import com.empmanage.sawon.service.SawonService;
import com.empmanage.sawon.service.dao.SawonDAO;
import com.empmanage.sawon.vo.SawonVO;

@Service("sawonService")
public class SawonServiceImpl implements SawonService {
	@Autowired
	private SawonDAO sawonDAO;

	@Override
	@Transactional
	public ArrayList<SawonVO> getAllSawon() {
		return sawonDAO.getAllSawon();
	}

	@Override
	public SawonVO getSawon(SawonVO sawonVO) {
		return sawonDAO.getSawon(sawonVO);
	}

	@Override
	public void insertSawon(SawonVO sawonVO) {
		sawonDAO.insertSawon(sawonVO);
	}

	@Override
	public void updateSawon(SawonVO sawonVO) {
		sawonDAO.updateSawon(sawonVO);
	}

	@Override
	public void deleteSawon(SawonVO sawonVO) {
		sawonDAO.deleteSawon(sawonVO);
	}
}
