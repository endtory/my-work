package com.empmanage.sawon.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.empmanage.sawon.service.UsedBookService;
import com.empmanage.sawon.service.dao.UsedBookDAO;
import com.empmanage.sawon.vo.UsedBookVO;

@Service
public class UsedBookServiceImpl implements UsedBookService {

    @Autowired
    private UsedBookDAO usedBookDAO;
    
    @Override
    public int getUsedBookCount() {
        return usedBookDAO.selectUsedBookCount();
    }
    
    @Override
    public ArrayList<UsedBookVO> getUsedBooksByPage(int startRow, int endRow) {
        
        return usedBookDAO.selectUsedBooksByPage(startRow, endRow);
    }

    @Override
    public List<UsedBookVO> getAllUsedBooks() {
        return usedBookDAO.selectAll();
    }

    @Override
    public UsedBookVO getUsedBook(int post_Id) {
        return usedBookDAO.selectId(post_Id);
    }
    
    @Override
    public int insertUsedBook(UsedBookVO vo) {
        return usedBookDAO.insert(vo);
    }

    @Override
    public int updateUsedBook(UsedBookVO vo) {
        return usedBookDAO.update(vo);
    }

    @Override
    public int deleteUsedBook(int post_Id) {
        return usedBookDAO.delete(post_Id);
    }

}
