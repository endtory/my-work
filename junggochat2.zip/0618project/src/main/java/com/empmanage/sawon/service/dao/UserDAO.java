package com.empmanage.sawon.service.dao;

import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.empmanage.sawon.vo.UserVO;

public interface UserDAO {
	
	public void insertUser(UserVO userVO);

	public Object findUserById(String user_Id); // UserVO 로

	public Object findUserByName(String name);

	public UserVO loginUser(Map<String, String> param); // => LoginDAO 로 

	public UserVO findUserBySeq(int user_Seq); // => LoginDAO 로 

	public void updateUserField(@Param("user_Seq") int user_Seq, @Param("field") String field, @Param("value") String value);

	public void updatePassword(@Param("user_Seq") int user_Seq, @Param("newPassword") String password);

	public String findNickname(String name);

}
