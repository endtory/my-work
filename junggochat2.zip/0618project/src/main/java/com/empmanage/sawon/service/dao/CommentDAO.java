package com.empmanage.sawon.service.dao;

import java.util.ArrayList;

import com.empmanage.sawon.vo.CommentVO;



public interface CommentDAO {

	void writeComments(CommentVO commentVO);

	ArrayList<CommentVO> getAllCommentsForPost(Integer pid);

	boolean deleteComment(int cid);

	Integer getPostIdByCommentId(int cid);

	void writeReplyComment(CommentVO commentVO);

	int getCommentCountForPost(int pid);

	CommentVO getCommentById(int commentId);

	void updateComment(CommentVO commentVO);
}
