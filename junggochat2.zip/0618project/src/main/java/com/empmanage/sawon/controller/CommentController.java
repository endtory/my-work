package com.empmanage.sawon.controller;

import java.util.ArrayList;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.empmanage.sawon.service.CommentService;
import com.empmanage.sawon.vo.CommentVO;



@Controller
public class CommentController {

	@Resource(name = "CommentService")
	private CommentService commentService;

	@RequestMapping(value = "/writeComment.do")
	public String writeComment(@ModelAttribute("commentVO") CommentVO commentVO, Model model) {

		if (commentVO.getParent_comment_id() == 0) {
			commentService.writeComment(commentVO); // �Ϲ� ���
		} else {
			commentService.writeReplyComment(commentVO); // ����
		}

		// ��� ��� ��ȸ
		ArrayList<CommentVO> comments = commentService.getAllCommentsForPost(commentVO.getPost_id());
		model.addAttribute("comments", comments);

		// �Խñ� �� �������� �̵�
		return "redirect:/showDetailPost.do?post_id=" + commentVO.getPost_id();
	}

	@RequestMapping(value = "/deleteComment.do")
	public String deleteComment(@RequestParam("cid") int commentId, RedirectAttributes redirectAttributes, Model model,
			CommentVO commentVO) {
		try {
			boolean isDeleted = commentService.deleteComment(commentId);

			if (isDeleted) {
				Integer postId = commentService.getPostIdByCommentId(commentId);

				redirectAttributes.addFlashAttribute("message", "����� �����߽��ϴ�");
				return "redirect:/showDetailPost.do?post_id=" + postId;
			} else {
				model.addAttribute("message", "��� ������ �����߽��ϴ�");
				return "/common/alertBack";
			}
		} catch (Exception e) {
			e.printStackTrace();
			model.addAttribute("message", "�ý��� ������ �߻��߽��ϴ�");
			return "/common/alertBack";
		}
	}
}