package com.empmanage.sawon.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.empmanage.sawon.service.OrderService;
import com.empmanage.sawon.service.UserService;
import com.empmanage.sawon.vo.MyOrderVO;
import com.empmanage.sawon.vo.UserVO;

@Controller
public class MyUpdateInfoController {
	@Autowired
	private UserService userService;

	// 마이페이지 - 내 정보 수정 페이지로 이동
	// 이동하면서 로그인한 사용자의 UserVO 가져감
	@RequestMapping(value="/myUpdateInfo.do")
	public String myUpdateInfo(HttpSession session, HttpServletRequest request) {
	    
		Integer userSeq = (Integer) session.getAttribute("user_seq");

	    if (userSeq == null) {
	        return "redirect:/login.do"; // 세션 없을 경우 로그인
	    }

	    UserVO user = userService.getUserBySeq(userSeq); // user_seq로 사용자 정보 조회
	    request.setAttribute("user", user); // JSP로 전달
	    // JSP 에서 사용자의 '이름'은 ${user.irum} 같은 식으로 정보 접근할 수 있다.

	    return "myUpdateInfo"; // 뷰 이름
	}
	
	/*
	 * 닉네임 중복 확인2 - myUpdateInfo.jsp에서 넘어옴.같은 서비스 ㅣ사용
	 * 중복확인 결과 <"available", true/false>으로 Map 반환
	*/
	@RequestMapping(value = "checkNameDuplicate.do", method = RequestMethod.POST)
	@ResponseBody
	public Map<String, Object> checkNameDuplicate(@RequestParam("name") String name) {
		System.out.println("닉네임 중복확인 요청 들어옴: " + name);
		System.out.println(">> 전달된 name 값: " + name);

		Map<String, Object> result = new HashMap<String, Object>();

		try {
			UserVO userVO = new UserVO();
			userVO.setName(name);
			userService.validateDuplicateByName(userVO);
			result.put("available", true);
		} catch (IllegalStateException e) {
			System.out.println(">> 중복된 닉네임: " + e.getMessage());
			result.put("available", false);
		} catch (Exception e) {
			System.out.println(">> 기타 예외: " + e.getMessage()); // ⭐ 예상치 못한 오류 확인용
			result.put("available", false);
		}

		return result;
	}

	/*
	 * 사용자 정보 (pw이외) 업데이트
	 */
	@RequestMapping(value = "updateUserField.do", method = RequestMethod.POST)
	@ResponseBody
	public Map<String, Object> updateUserField(@RequestParam("field") String field, @RequestParam("value") String value,
			HttpSession session) {
		Map<String, Object> result = new HashMap<String, Object>();
		Integer userSeq = (Integer) session.getAttribute("user_seq");

		// seq == null : 비로그인상태
		// ※ 세션이 항상 null일 수 없기 때문에 session == null은 적절하지 않다.
		if (userSeq == null) {
			result.put("success", false);
			result.put("message", "로그인이 필요합니다.");
			return result;
		}

		try {
			userService.updateUserField(userSeq, field, value);
			result.put("success", true);
		} catch (Exception e) {
			result.put("success", false);
			result.put("message", "업데이트 실패: " + e.getMessage());
		}

		return result;
	}

	/*
	 * 사용자 정보(pw) 업데이트
	 */
	@RequestMapping(value = "updatePassword.do", method = RequestMethod.POST)
	@ResponseBody
	public Map<String, Object> updatePassword(@RequestParam("currentPassword") String currentPw,
			@RequestParam("newPassword") String newPw, HttpSession session) {

		Map<String, Object> result = new HashMap<String, Object>();
		Integer userSeq = (Integer) session.getAttribute("user_seq");

		try {
			userService.updatePassword(userSeq, currentPw, newPw);
			result.put("success", true);
		} catch (IllegalArgumentException e) {
			result.put("success", false);
			result.put("message", e.getMessage());
		}

		return result;
	}
	
	

}
