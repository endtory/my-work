package com.empmanage.sawon.service.dao;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.empmanage.sawon.vo.UsedBookVO;

public interface UsedBookDAO {
    List<UsedBookVO> selectAll();
    UsedBookVO selectId(int post_id);
    int insert(UsedBookVO vo);
    int update(UsedBookVO vo);
    int delete(int post_id);
	int selectUsedBookCount();
	ArrayList<UsedBookVO> selectUsedBooksByPage(@Param("startRow") int startRow,  @Param("endRow")int endRow);
}