package com.empmanage.sawon.encoder;

import org.springframework.security.authentication.encoding.MessageDigestPasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class SHA256PasswordEncoder extends MessageDigestPasswordEncoder {

	public SHA256PasswordEncoder() {
		super("SHA-256");
	}

}