package com.empmanage.sawon.service;

import com.empmanage.sawon.vo.UserVO;

public interface UserService {
	boolean insertUser(UserVO userVO);
    void validateDuplicateByUserId(UserVO userVO);
	void validateDuplicateByName(UserVO userVO);
	public UserVO getUserBySeq(int user_Seq);
	
	public void updateUserField(Integer user_Seq, String field, String value);
	public void updatePassword(Integer user_Seq, String currentPw, String newPw);
}