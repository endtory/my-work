package com.empmanage.sawon.service.dao;

import java.util.List;
import java.util.Map;

import com.empmanage.sawon.vo.MyOrderVO;

public interface MyOrderDAO {

	public List<MyOrderVO> getOrdersByUserId(Map<String, Object> params);

	public int countOrdersByUserId(Map<String, Object> params);
	
	// (�ӽ�)
	public MyOrderVO getOrderByOrderId(int orderId);
}
