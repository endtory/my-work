package com.empmanage.sawon.service;


import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.empmanage.sawon.vo.BookSearchResult;
import com.empmanage.sawon.vo.BookVO;
import com.empmanage.sawon.vo.ReviewVO;
import com.empmanage.sawon.vo.SawonVO;

public interface BookService {
	BookSearchResult searchBooks(String query, int startnum) throws Exception;
	
	ArrayList<BookVO> getBest() throws Exception;

	ArrayList<BookVO> getNew() throws Exception;
    
	ArrayList<BookVO> getAllBook();

	BookVO getTelinfo(BookVO bookVO);
	
	ArrayList<ReviewVO> getAllReview();
	ArrayList<ReviewVO> getAllReviewByIsbn(String isbn);
	
	void insertReview(ReviewVO reviewVO) throws Exception;
	void updateReview(ReviewVO reviewVO) throws Exception;
	void deleteReview(ReviewVO reviewVO) throws Exception;

	double getAverageRating(String isbn);

	void incrementLikes(int cid);
}