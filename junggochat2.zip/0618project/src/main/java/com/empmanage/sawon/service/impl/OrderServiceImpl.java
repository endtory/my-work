package com.empmanage.sawon.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.empmanage.sawon.service.OrderService;
import com.empmanage.sawon.service.dao.MyOrderDAO;
import com.empmanage.sawon.vo.MyOrderVO;

@Service
public class OrderServiceImpl implements OrderService {

	@Autowired
	private MyOrderDAO myOrderDAO;
	
	@Override
	public List<MyOrderVO> getOrdersByUserId(Map<String, Object> params) {
		return myOrderDAO.getOrdersByUserId(params);
	}
	
	@Override
	public int countOrdersByUserId(Map<String, Object> params) {
		return myOrderDAO.countOrdersByUserId(params);
	}
	
	// (�ӽ�)
	@Override
	public MyOrderVO getOrderByOrderId(int orderId) {
		return myOrderDAO.getOrderByOrderId(orderId);
	}

}
