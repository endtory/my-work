package com.empmanage.sawon.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.w3c.dom.*;
import org.xml.sax.InputSource;

import com.empmanage.sawon.service.BookService;
import com.empmanage.sawon.service.dao.BookDAO;
import com.empmanage.sawon.service.dao.SawonDAO;
import com.empmanage.sawon.vo.BookSearchResult;
import com.empmanage.sawon.vo.BookVO;
import com.empmanage.sawon.vo.ReviewVO;

import javax.xml.parsers.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.io.*;

@Service("bookService")
public class BookServiceImpl implements BookService {

	@Autowired
	private BookDAO bookDAO;
	
	SimpleDateFormat naverDateFormat = new SimpleDateFormat("yyyyMMdd");
	
    
    
	
	@Override
	@Transactional
	public ArrayList<BookVO> getAllBook() {
		// TODO Auto-generated method stub
		return bookDAO.getAllBook();
	}	
	
	public ArrayList<BookVO> getBest() {
    	return bookDAO.getBest();
    }
	
    public ArrayList<BookVO> getNew() {
    	return bookDAO.getNew();
    }
	
	@Override
	@Transactional
	public BookVO getTelinfo(BookVO bookVO) {
	     return bookDAO.getTelinfo(bookVO); 
	    }
	
	@Override
	@Transactional
	public ArrayList<ReviewVO> getAllReview() {
		// TODO Auto-generated method stub
		return bookDAO.getAllReview();
	}	
	
	
	@Override
	public void insertReview(ReviewVO reviewVO) {
		bookDAO.insertReview(reviewVO);
	}

	@Override
	public void updateReview(ReviewVO reviewVO) {
		bookDAO.updateReview(reviewVO);
	}

	@Override
	public void deleteReview(ReviewVO reviewVO) {
		bookDAO.deleteReview(reviewVO);
	}
	
	@Override
	public ArrayList<ReviewVO> getAllReviewByIsbn(String isbn) {
	    return bookDAO.getAllReviewByIsbn(isbn);
	}
	
	// ����
	@Override
	public double getAverageRating(String isbn) {
	    return bookDAO.getAverageRating(isbn);
	}
	
	
	//���ƿ��ư
	@Override
	public void incrementLikes(int cid) {
		bookDAO.incrementLikes(cid);
	}

    public BookSearchResult searchBooks(String query, int startnum) {
        String clientId = "k1JoyA9mKyzQfVoyHmUW";
        String clientSecret = "liT0c_CuXU";
        ArrayList<BookVO> resultList = new ArrayList<BookVO>();
        int total = 0;

        try {
            String text = URLEncoder.encode(query, "UTF-8");
            String apiURL = "https://openapi.naver.com/v1/search/book_adv.xml?d_titl=" + text + "&start=" + Math.max(1, startnum);

            URL url = new URL(apiURL);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            con.setRequestProperty("X-Naver-Client-Id", clientId);
            con.setRequestProperty("X-Naver-Client-Secret", clientSecret);

            BufferedReader br = new BufferedReader(
                new InputStreamReader(con.getInputStream(), "UTF-8") // Java 6�� StandardCharsets ��� �Ұ�
            );

            StringBuilder response = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) {
                response.append(line);
            }
            br.close();

            // XML �Ľ�
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            InputSource is = new InputSource(new StringReader(response.toString()));
            Document doc = builder.parse(is);

            total = Integer.parseInt(getTagValue(doc.getDocumentElement(), "total"));  // ��Ʈ element
            NodeList items = doc.getElementsByTagName("item");
            
            
            for (int i = 0; i < items.getLength(); i++) {
                Element item = (Element) items.item(i);
                BookVO book = new BookVO();
                
                book.setIsbn(getTagValue(item, "isbn"));
                book.setTitle(getTagValue(item, "title"));
                book.setAuthor(getTagValue(item, "author"));
                book.setPublisher(getTagValue(item, "publisher"));
                book.setPrice(Integer.parseInt(getTagValue(item, "discount")));     // ����
                book.setSummary(getTagValue(item, "description"));
                book.setImgurl(getTagValue(item, "image"));
                book.setLink(getTagValue(item, "link"));
                resultList.add(book);
                
                String pubDateStr = getTagValue(item, "pubdate");
                
                Date pubDate = null;
                try {
                    if (pubDateStr != null && !pubDateStr.trim().isEmpty()) {
                        pubDate = naverDateFormat.parse(pubDateStr);
                    }
                } catch (ParseException e) {
                    e.printStackTrace(); // �Ǵ� �ΰ� ó��
                }
                book.setPub_date(pubDate);
                
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return new BookSearchResult(resultList, total);
    }

    private String getTagValue(Element item, String tag) {
        NodeList nodes = item.getElementsByTagName(tag);
        if (nodes.getLength() > 0) {
            return nodes.item(0).getTextContent();
        }
        return "";
    }

	
}