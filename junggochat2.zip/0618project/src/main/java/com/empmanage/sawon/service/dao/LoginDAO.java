package com.empmanage.sawon.service.dao;

import java.util.Map;

import com.empmanage.sawon.vo.UserVO;

public interface LoginDAO {
	// {user_Id, pw} map ��ü
	public UserVO loginUser(Map<String, String> param);
}
