package com.empmanage.sawon.service;

import java.util.ArrayList;


import com.empmanage.sawon.vo.SawonVO;

public interface SawonService {

	ArrayList<SawonVO> getAllSawon() throws Exception;

	SawonVO getSawon(SawonVO sawonVO) throws Exception;

	void insertSawon(SawonVO sawonVO) throws Exception;

	void updateSawon(SawonVO sawonVO) throws Exception;

	void deleteSawon(SawonVO sawonVO) throws Exception;
}
