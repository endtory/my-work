package com.empmanage.sawon.vo;

import java.util.Date;

public class ReviewVO {

    private int cid;                // ���� ID
    private Integer ccid; // �θ� ��� ID (nullable ����)
    private String isbn;           // ���� ISBN
    private String user_id;         // �ۼ���
    private String review_text;     // ���� ����
    private double review_score;    // ����
    private Date review_date;       // �ۼ���
    private String image_path;      // ÷�� �̹���
    private int likes;             // ���ƿ� ��
    
    
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public Integer getCcid() {
		return ccid;
	}
	public void setCcid(Integer ccid) {
		this.ccid = ccid;
	}
	public String getIsbn() {
		return isbn;
	}
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getReview_text() {
		return review_text;
	}
	public void setReview_text(String review_text) {
		this.review_text = review_text;
	}
	public double getReview_score() {
		return review_score;
	}
	public void setReview_score(double review_score) {
		this.review_score = review_score;
	}
	public Date getReview_date() {
		return review_date;
	}
	public void setReview_date(Date review_date) {
		this.review_date = review_date;
	}
	public String getImage_path() {
		return image_path;
	}
	public void setImage_path(String image_path) {
		this.image_path = image_path;
	}
	public int getLikes() {
		return likes;
	}
	public void setLikes(int likes) {
		this.likes = likes;
	}
    
    
    

    
   

    
}
