package com.empmanage.sawon.service.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.ModelAttribute;

import com.empmanage.sawon.vo.SawonVO;

public interface SawonDAO {
	ArrayList<SawonVO> getAllSawon();

	SawonVO getSawon(SawonVO sawonVO);

	void insertSawon(SawonVO sawonVO);

	void updateSawon(SawonVO sawonVO);

	void deleteSawon(SawonVO sawonVO);
}