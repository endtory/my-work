package com.empmanage.sawon.service.dao;

import java.util.ArrayList;

import com.empmanage.sawon.vo.BookVO;
import com.empmanage.sawon.vo.ReviewVO;
import com.empmanage.sawon.vo.SawonVO;

public interface BookDAO {
	BookVO getOnebook(BookVO bookVO);
	
	ArrayList<BookVO> getBest();

	ArrayList<BookVO> getNew();
	
	ArrayList<BookVO> getAllBook();
	
	BookVO getTelinfo(BookVO bookVO);

	ArrayList<ReviewVO> getAllReview();
	ArrayList<ReviewVO> getAllReviewByIsbn(String isbn);
	
	void insertReview(ReviewVO reviewVO);
	void updateReview(ReviewVO reviewVO);
	void deleteReview(ReviewVO reviewVO);
	
	// ����
	public double getAverageRating(String isbn);
	
	//���ƿ�
	void incrementLikes(int cid);
}
