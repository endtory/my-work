<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>

</head>
<body>
	<h1>도서 검색 시작</h1>
	<hr>
	<script>
		location.href = "MainPage.do"; 
		//location.href = "sawonAll.do";
	</script>
</body>
</html>