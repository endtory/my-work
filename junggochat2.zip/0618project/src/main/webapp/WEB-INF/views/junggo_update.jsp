<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>게시글 수정</title>
<link rel="stylesheet" href="${pageContext.request.contextPath}/resources/css/junggo_update.css" />
</head>
<body>

<jsp:include page="/common/header.jsp" />

<h2>게시글 수정</h2>

<form action="${pageContext.request.contextPath}/junggo_update.do" method="post" enctype="multipart/form-data">
    <input type="hidden" name="post_id" value="${book.post_id}" />

    <input type="text" name="title" value="${book.title}" placeholder="제목을 입력해 주세요" class="input-text" required>
    
    <input type="number" name="price" value="${book.price}" placeholder="가격을 입력해 주세요" class="input-number" required min="0">
    
    <input type="text" name="isbn" value="${book.isbn}" placeholder="ISBN 입력 (선택)" class="input-text">
    
    <select name="sale_status" required>
        <option value="">판매 상태 선택</option>
        <option value="판매중" ${book.sale_status eq '판매중' ? 'selected' : ''}>판매중</option>
        <option value="판매완료" ${book.sale_status eq '판매완료' ? 'selected' : ''}>판매완료</option>
    </select>
    
    <select name="sale_type" required>
        <option value="">판매 유형 선택</option>
        <option value="used" ${book.sale_type eq 'used' ? 'selected' : ''}>중고</option>
        <option value="free" ${book.sale_type eq 'free' ? 'selected' : ''}>나눔</option>
    </select>

    <input type="hidden" name="user_id" value="${book.user_id}">

    <textarea name="content" placeholder="내용을 입력하세요" class="input-text" rows="5" required>${book.content}</textarea>

    <!-- 이미지 업로드 (복수 허용) -->
    <label for="imageUpload" class="btn-upload">사진등록</label>
    <input type="file" id="imageUpload" name="images" accept="image/*" multiple>

    <!-- 기존 이미지 미리보기 -->
    <div id="previewContainer" class="preview-container">
	</div>

    <input type="submit" value="수정" class="btn-submit">

    <button type="button" class="btn-reset" onclick="location.href='${pageContext.request.contextPath}/junggo_view.do?post_id=${book.post_id}'">취소</button>
</form>

<jsp:include page="/common/footer.jsp" />

</body>
</html>
