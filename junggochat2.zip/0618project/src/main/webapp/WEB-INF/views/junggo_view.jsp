<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>

<!-- update -->
<%-- 세션에서 로그인한 사용자 ID를 꺼내서 JSTL 변수로 등록 --%>
<c:set var="loginUserId" value="${sessionScope.user_id}" />

<html>
<head>
    <title>중고도서 상세 보기</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/resources/css/junggo_view.css">
    
    <script>
    	const contextPath = '${pageContext.request.contextPath}';
	</script>
    
    <script src="${pageContext.request.contextPath}/resources/js/junggo_view.js"></script>
    <script src="${pageContext.request.contextPath}/resources/js/chat_popup.js"></script>
</head>
<body>
<jsp:include page="/common/header.jsp" />

<%-- 작성자와 로그인 유저가 같을 때만 보이게 --%>
<c:if test="${loginUserId eq book.user_id}">
	<form action="${pageContext.request.contextPath}/junggo_update.do" method="get">
    	<input type="hidden" name="post_id" value="${book.post_id}" />
    	<button type="submit">수정</button>
	</form>
	
	<form action="${pageContext.request.contextPath}/junggo_delete.do" method="post" style="display:inline;"
		onsubmit="return confirm('정말 삭제하시겠습니까?');">
		<input type="hidden" name="post_id" value="${book.post_id}">
		<button type="submit">삭제</button>
	</form>
</c:if>

<!-- ----------------------------------------------------- -->

<h2>${book.title}</h2>
<p>${formattedDate}</p>

<div class="bookimage">
  <c:forEach var="imgPath" items="${fn:split(book.image_path, ';')}" varStatus="status">
    <c:choose>
      <c:when test="${fn:startsWith(imgPath, '/resources/uploads/')}">
        <img class="slide" src="${pageContext.request.contextPath}${imgPath}" style="${status.index == 0 ? '' : 'display:none;'}" />
      </c:when>
      <c:otherwise>
        <img class="slide" src="${pageContext.request.contextPath}/resources/uploads/${imgPath}" style="${status.index == 0 ? '' : 'display:none;'}" />
      </c:otherwise>
    </c:choose>
  </c:forEach>
</div>

<button id="prevBtn">이전</button>
<button id="nextBtn">다음</button>

<p>판매상태: ${book.sale_status}</p>
<p>도서 제목: ${book.title}</p>
<p>가격: ${book.price}원</p>
<p>상품 상태: 깨끗함</p>
<p>결제 방법: 카카오페이</p>
<p>판매자 아이디: ${book.user_id}</p>

<!-- update -->
<form id="chatForm">
    <input type="hidden" id="userId" value="${book.user_id}" />
    <input type="hidden" id="chatRoomId" value="${chatRoomId != null ? chatRoomId : ''}" />
    <button type="button" id="chatButton">구매 문의 채팅</button>
</form>
<!-- !!!!!!!!!!!! -->

<hr>

<h3>글 내용</h3>
<p>${book.content}</p>

<p>구매 문의는 채팅을 통해 이루어집니다. 상단의 구매 문의 채팅을 눌러주세요.</p>

<form action="${pageContext.request.contextPath}/junggo_write.do" method="get" style="display:inline;">
    <button type="submit">글쓰기</button>
</form>

<form action="${pageContext.request.contextPath}/junggo_list.do" method="get" style="display:inline;">
    <button type="submit">목록</button>
</form>

<jsp:include page="/common/footer.jsp" />
</body>
</html>
