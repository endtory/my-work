
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"%>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>


<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Welcome BookMall</title>

<link rel="stylesheet" href="${pageContext.request.contextPath}/resources/css/bookview.css">

	</head>
	
	<body>
	<jsp:include page="/common/header.jsp" />
	
	    
	    
  <!-- 도서 상세 -->
    <div class="content_top">
      <img class="content_img" src="${book.image_path}" alt="${book.title}">
		
      <div class="ct_right_area">
		<h1>
		  ${book.title}
		  <c:if test="${averageRating > 0}">
		    <span class="average-rating">
		      <img src="${pageContext.request.contextPath}/IMG/flower.png" alt="벚꽃" class="rating-flower-icon">
		      <fmt:formatNumber value="${averageRating}" maxFractionDigits="1"/>
		    </span>
		  </c:if>
		</h1>


        <h3>${book.author} 지음</h3>
        <p>출판사 ${book.publisher} | 장르 ${book.genre}</p>
        <p>출판일 <fmt:formatDate value="${book.pub_date}" pattern="yyyy년 MM월 dd일" /></p>
        <p>정가 : <fmt:formatNumber value="${book.price}" pattern="#,### 원" /></p>
                <c:set var="discountPrice" value="${book.price * book.discount_price}" />
                <c:set var="salePrice" value="${book.price - discountPrice}" />
        <p>판매가 :
    <fmt:formatNumber value="${book.discount_price}" pattern="#,### 원" />
    <span class="discount-highlight">[<fmt:formatNumber value="${10}" pattern="###" />% 할인]</span>
</p>

        <p>적립/혜택 : <fmt:formatNumber value="${book.price * 0.05}" pattern="#,### 원" /></p>
		<p>배송료 3000원 (5만원 이상 구매시 무료)</p>
		<div class="button_quantity">
		    주문수량 <input id="quantityInput" type="number" value="1" min="1">
		    <div class="quantity_controls">
		        <button onclick="changeQuantity(1)">▲</button>
		        <button onclick="changeQuantity(-1)">▼</button>
		    </div>
		</div>

		
		<!-- 장바구니 버튼 -->
	<div class="button_set">
		<form id="cartForm" action="wishlist.do" method="post" style="display: inline-block; margin-right: 10px;">
		    <input type="hidden" name="isbn" value="${book.isbn}">
		    <input type="hidden" name="user_id" value="${user.user_Id}">
		    <input type="hidden" name="list_type" value="cart">
		    <input type="hidden" name="count" id="cartQuantity" value="1">
		    <button type="submit" class="btn_cart">장바구니</button>
		</form>

		<!-- 바로구매 버튼 -->
          <form id="paymentForm" action="payment.do" method="post" style="display: inline-block; margin-right: 10px;">
		    <input type="hidden" name="isbn" value="${book.isbn}">
		    <input type="hidden" name="user_id" value="${user.user_Id}">
		    <input type="hidden" name="quantity" id="paymentQuantity" value="1">
		    <button type="submit" class="btn_buy">바로구매</button>
		</form>
          
          <!-- 찜 버튼 -->
			<form id="wishForm" action="wishlist.do" method="post" style="display: inline-block;">
			    <input type="hidden" name="isbn" value="${book.isbn}">
			    <input type="hidden" name="user_id" value="${user.user_Id}">
			    <input type="hidden" name="list_type" value="wishlist">
			    <button type="submit" class="btn_wish">♥</button>
			</form>
<!-- 	장바구니/찜하기 → wishlist.do로 전송, list_type으로 구분 -->			
		
		
		<script>
		  function changeQuantity(amount) {
		    const input = document.getElementById("quantityInput");
		    let newValue = parseInt(input.value) + amount;
		    if (newValue < 1) newValue = 1;
		    input.value = newValue;
		    document.getElementById("paymentQuantity").value = newValue;
		    document.getElementById("cartQuantity").value = newValue;
		  }
		
		  document.getElementById("quantityInput").addEventListener("input", function() {
		    let val = parseInt(this.value);
		    if (isNaN(val) || val < 1) val = 1;
		    this.value = val;
		    document.getElementById("paymentQuantity").value = val;
		    document.getElementById("cartQuantity").value = val;
		  });
		
		  // 로그인 체크 (공통) // payment,cart,wish
		<!-- 로그인 여부 변수 설정-->

		const isLoggedIn = "${sessionScope.user_seq == null ? 'false' : 'true'}";

		  ["paymentForm", "cartForm", "wishForm"].forEach(formId => {
		    const form = document.getElementById(formId);
		    form.addEventListener("submit", function(e) {
		      if (!isLoggedIn) {
		        e.preventDefault();
		        document.getElementById("loginModal").style.display = "flex";
		      }
		    });
		  });
		</script>
		
		<!-- 로그인 모달 (공통) -->
		<div id="loginModal" class="login-modal-overlay">
			<form action="login.do" method="get">
	            <input type="hidden" name="redirect" value="bookview.do?isbn=${book.isbn}">
				<div class="login-modal">
				    <h2>로그인 후 이용 가능합니다</h2>
				    <p>로그인 페이지로 이동하시겠습니까?</p>
				    <div class="modal-buttons">
						<button class="cancel-btn" onclick="closeLoginModal()">취소</button>
						<button type="submit">확인</button>
				    </div>
		  		</div>
		  	</form>
		</div>
		
		<script>
		  function closeLoginModal() {
		    document.getElementById("loginModal").style.display = "none";
		  }
		
		  function goToLogin() {
		    window.location.href = "/login.do";
		  }
		</script>
        </div>
      </div>
    </div>

    <!-- 줄거리 -->
    <div class="book-summary">
      <h1>상품정보</h1>
      <p>판매량 ${book.sales }부수의 대작!</p><br>
      <h2>▶줄거리</h2><br>
      <p>${book.summary}</p>
    </div>
	


	<script>
	  // 로그인 여부를 정확히 판단하는 안전한 방법
	  const isLoggedIn = "${sessionScope.user_seq == null ? 'false' : 'true'}";
	</script>

	<!-- 
    <br><br>
    <div class="one">리뷰</div><br><br> -->
    
    
	<!-- 방법4 방법3scope문제 해결 review_fragment.jsp 활용-->
	<%@ include file="/WEB-INF/views/review_fragment.jsp" %>
	
	
	
		<!--  벚꽃점수 랜더링 -->
	<script>
		const ctx = "${pageContext.request.contextPath}";
		const filled = ctx + "/IMG/flower.png";
		const half = ctx + "/IMG/flower_half.png";
		const empty = ctx + "/IMG/noflower.png";
		
		document.querySelectorAll('.flower-display').forEach(container => {
		    const rating = parseFloat(container.dataset.rating);
		    container.innerHTML = ''; // 초기화
		    for (let i = 1; i <= 5; i++) {
		        const img = document.createElement('img');
		        img.src = rating >= i ? filled : (rating >= i - 0.5 ? half : empty);
		        container.appendChild(img);
		    }
		});
	</script>
	
	
	
	<div>${sessionScope.user_seq}</div>
<%-- 	<img height = "50px" src = "${pageContext.request.contextPath}/IMG/Logo.png"/> --%>
    <%@ include file="/common/footer.jsp" %>


	

</body>
</html>


