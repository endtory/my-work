<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<link rel="icon" href="./resources/images/favicon3.ico" type="image/x-icon">
<link rel="stylesheet" type="text/css" href="./resources/style/postDetail.css">
<title>${post.title}</title>
</head>
<body>
	<jsp:include page="/common/header.jsp" />
	<!-- 상단 메뉴 버튼용 form -->
	<form id="myForm" method="post">
		<table>
			<tr>
				<td colspan="4" class="btn-row"><input type="submit" value="모두보기" onclick="submitTo('goPost.do')" /> <input type="submit" value="글쓰기" onclick="submitTo('goWritePost.do')" /> <input type="submit" value="수정하기" onclick="submitTo('goWritePost.do?post_id=${post.post_id}')" /> <input type="submit" value="삭제하기" onclick="submitTo('deletePost.do?post_id=${post.post_id}')" /></td>
			</tr>

			<tr>
				<td colspan="4" class="post-card">
					<h3 style="margin: 4px 0 0 0;">[${post.category}]</h3>
					<h2 style="margin: 4px 0 0 0;">${post.title}</h2>
					<div class="comment-meta">
						<b>${post.user_id}</b> |
						<fmt:formatDate value="${post.post_date}" pattern="yy-MM-dd" />
					</div>
					<div style="margin-top: 10px;">
						<c:out value="${post.postContentsWithBr}" escapeXml="false" />
					</div>
				</td>
			</tr>
		</table>
	</form>

	<!-- 댓글 출력 테이블 -->
	<table>
		<!-- 최상위 댓글 입력폼 -->
		<tr>
			<td colspan="4" class="comment-card">
				<form action="writeComment.do" method="post">
					<textarea name="comment_contents" rows="4" placeholder="댓글을 작성해 주세요" style="resize: none;"></textarea>
					<input type="text" name="user_id" placeholder="작성자 이름" /> <input type="hidden" name="post_id" value="${post.post_id}" /> <input type="hidden" name="parent_comment_id" value="0" /> <input type="submit" value="댓글쓰기" />
				</form>
			</td>
		</tr>

		<!-- 댓글 및 대댓글 출력 -->
		<c:forEach var="comment" items="${comments}">
			<tr>
				<td colspan="4" class="${comment.parent_comment_id == 0 ? 'comment-card' : 'reply-card'}">
					<div class="${comment.parent_comment_id != 0 ? 'reply-form' : ''}">
						<div>
							<b>${comment.user_id}</b> |
							<fmt:formatDate value="${comment.comment_date}" pattern="yy-MM-dd" />
						</div>
						<div style="margin-top: 5px;">
							<c:out value="${comment.comment_contentsWithBr}" escapeXml="false" />
						</div>

						<div class="comment-buttons">
							<c:if test="${comment.parent_comment_id == 0}">
								<button type="button" onclick="showReplyForm(${comment.comment_id})">답글쓰기</button>
							</c:if>

							<form action="deleteComment.do" method="post" style="display: inline;">
								<input type="hidden" name="comment_id" value="${comment.comment_id}" /> <input type="hidden" name="post_id" value="${post.post_id}" />
								<button type="submit">댓글삭제</button>
							</form>
						</div>
					</div>
				</td>
			</tr>

			<!-- 대댓글 입력 폼 -->
			<c:if test="${comment.parent_comment_id == 0}">
				<tr id="replyForm-${comment.comment_id}" style="display: none;">
					<td colspan="4" class="reply-card">
						<form action="writeComment.do" method="post">
							<div class="reply-form">
								<textarea name="comment_contents" rows="3" placeholder="답글을 입력하세요"></textarea>
								<input type="text" name="user_id" placeholder="작성자 이름" /> <input type="hidden" name="post_id" value="${post.post_id}" /> <input type="hidden" name="parent_comment_id" value="${comment.comment_id}" /> <input type="submit" value="답글쓰기" />
							</div>
						</form>
					</td>
				</tr>
			</c:if>
		</c:forEach>
	</table>

	<script>
		function submitTo(actionUrl) {
			const form = document.getElementById('myForm');
			form.action = actionUrl;
		}

		function showReplyForm(commentId) {
			const form = document.getElementById("replyForm-" + commentId);
			form.style.display = (form.style.display === "none") ? "table-row" : "none";
		}
	</script>
	<jsp:include page="/common/footer.jsp" />
</body>
</html>