package com.empmanage.sawon.service;

import java.util.ArrayList;

import com.empmanage.sawon.vo.*;

public interface SawonService {//interface
	ArrayList <SawonVO> getAllSawon() throws Exception;
}
