package com.empmanage.sawon.service.dao;

import java.util.ArrayList;


import com.empmanage.sawon.vo.SawonVO;



//mapper interface  ���� 
public interface SawonDAO { // interface & mapping 
	ArrayList <SawonVO> getAllSawon();
	                                 
}


